# NFT_Purchase_Without_Digital_Wallet


## Getting Started

Create a project using this example:
Run command

```bash
npx thirdweb create --template next-typescript-starter
```

```bash
npm init -y
```

```bash
npm install
```

```bash
npm run dev
```

